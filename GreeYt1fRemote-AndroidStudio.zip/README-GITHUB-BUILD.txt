GREE YT1F REMOTE - GITHUB ACTIONS BUILD

Upload the contents of this ZIP to the ROOT of your GitHub repository.
The included workflow is .github/workflows/android.yml.
In GitHub, open Actions > Build Gree YT1F APK > Run workflow.
When the run succeeds, download the Gree-YT1F-APK artifact and extract app-debug.apk.

Important: The original ZIP did not contain a real Gradle Wrapper JAR. To avoid pretending otherwise,
the GitHub Actions workflow generates the official wrapper using Gradle 8.9 on the runner, then builds.
The placeholder gradlew script in this ZIP will work after that workflow-generated JAR exists.
This ZIP has NOT been verified by a successful Android build. IR protocol behavior also remains unverified.
