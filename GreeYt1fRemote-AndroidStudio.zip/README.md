# Gree YT1F AC Remote (Native Android Project)

A 100% offline, privacy-first native Android application for **Gree YT1F** Air Conditioners built with **Kotlin** and **Jetpack Compose**, using Android's **ConsumerIrManager** API.

Modelled directly after the **Gree YT1F / YT1FF** infrared remote control.

---

## 1. Verified Gree YT1F Protocol Details
- **Carrier Frequency**: 38,000 Hz (38 kHz)
- **Modulation**: Pulse Distance Modulation (PDM)
- **Header**: 9,000 µs Mark, 4,500 µs Space
- **Bit 0**: 620 µs Mark, 540 µs Space
- **Bit 1**: 620 µs Mark, 1,600 µs Space
- **Frame**: 67 bits total (Block 1: 32 bits, 20 ms inter-block gap, Block 2: 32 bits + 3 trailer bits 0b000)
- **Dynamic Checksum**: Formula `((b0 + b1 + b2 + b3 + b4_high + b5_high + b6_high + 0x0A) & 0x0F) << 4`
- **I-Feel 2-Byte Beacon**: Transmits `[temperature, 0xA5]` for active thermostat feedback.

---

## 2. Target Device: Infinix Smart 204G
- **Built-in IR Emitter**: The app queries `irManager.hasIrEmitter()`.
- **Safe Hardware Fallback**: If the specific hardware revision lacks an internal IR LED, the app alerts the user without crashing. External USB-C or 3.5mm IR blaster dongles (Baseus, ZaZa, Tiqiaa) are fully supported.

---

## 3. How to Build the APK on an Android Phone (No PC Needed)

### Using Termux (Recommended & Free)
1. Install **Termux** from F-Droid.
2. Update packages and install OpenJDK 17 and Gradle:
   ```bash
   pkg update -y && pkg install openjdk-17 gradle git unzip -y
   ```
3. Unzip the project:
   ```bash
   unzip GreeYt1fRemote-AndroidStudio.zip -d GreeYT1F
   cd GreeYT1F
   chmod +x gradlew
   ```
4. Compile the APK:
   ```bash
   gradle assembleDebug
   ```
5. Install the generated APK on your phone:
   ```bash
   termux-open app/build/outputs/apk/debug/app-debug.apk
   ```
