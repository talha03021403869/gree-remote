package com.gree.yt1fremote

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.gree.yt1fremote.data.AcMode
import com.gree.yt1fremote.data.FanSpeed
import com.gree.yt1fremote.data.RemoteState
import com.gree.yt1fremote.ir.GreeYt1fProtocol
import com.gree.yt1fremote.ui.RemoteScreen
import com.gree.yt1fremote.ui.theme.GreeYt1fTheme

class MainActivity : ComponentActivity() {

    private var irManager: ConsumerIrManager? = null
    private var vibrator: Vibrator? = null
    private var toneGenerator: ToneGenerator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Android ConsumerIrManager
        irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        toneGenerator = ToneGenerator(AudioManager.STREAM_SYSTEM, 65)

        // Load persisted state from SharedPreferences
        val prefs = getSharedPreferences("gree_yt1f_prefs", Context.MODE_PRIVATE)
        val initialPower = prefs.getBoolean("power", false)
        val initialTemp = prefs.getInt("temp", 25)
        val initialMode = AcMode.valueOf(prefs.getString("mode", AcMode.COOL.name) ?: AcMode.COOL.name)
        val initialFan = FanSpeed.valueOf(prefs.getString("fan", FanSpeed.AUTO.name) ?: FanSpeed.AUTO.name)
        val initialSoundEnabled = prefs.getBoolean("button_sound_enabled", true)

        setContent {
            GreeYt1fTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var soundEnabled by remember { mutableStateOf(initialSoundEnabled) }
                    var state by remember {
                        mutableStateOf(
                            RemoteState(
                                power = initialPower,
                                temperature = initialTemp,
                                mode = initialMode,
                                fanSpeed = initialFan
                            )
                        )
                    }

                    val hasIr = remember { irManager?.hasIrEmitter() == true }

                    RemoteScreen(
                        state = state,
                        hasIrEmitter = hasIr,
                        onStateChange = { newState ->
                            state = newState
                            // Persist settings locally
                            prefs.edit().apply {
                                putBoolean("power", newState.power)
                                putInt("temp", newState.temperature)
                                putString("mode", newState.mode.name)
                                putString("fan", newState.fanSpeed.name)
                                apply()
                            }
                            // Transmit verified Gree YT1F IR signal
                            sendIrCommand(newState)
                        },
                        onLightToggle = { newState ->
                            state = newState
                            prefs.edit().putBoolean("light", newState.light).apply()
                            // Send the LIGHT toggle while explicitly preserving the current power state.
                            sendIrCommand(newState.copy(power = state.power))
                        },
                        soundEnabled = soundEnabled,
                        onSoundToggle = {
                            soundEnabled = !soundEnabled
                            prefs.edit().putBoolean("button_sound_enabled", soundEnabled).apply()
                        },
                        onButtonPressed = {
                            if (soundEnabled) {
                                try { toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 85) } catch (_: Exception) {}
                            }
                        },
                        onTransmitIFeelBeacon = {
                            transmitIFeelBeacon(state.temperature)
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        toneGenerator?.release()
        toneGenerator = null
        super.onDestroy()
    }

    private fun sendIrCommand(state: RemoteState) {
        // Haptic feedback
        try {
            vibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}

        val manager = irManager
        if (manager == null || !manager.hasIrEmitter()) {
            Toast.makeText(
                this,
                "IR Blaster diode not detected. Attach a 3.5mm/Type-C IR dongle.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        try {
            // Encode complete state into verified 38kHz pulse pattern
            val pattern = GreeYt1fProtocol.encodeStateToPulses(state)
            manager.transmit(GreeYt1fProtocol.CARRIER_FREQUENCY, pattern)
        } catch (e: Exception) {
            Toast.makeText(this, "IR transmission failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun transmitIFeelBeacon(temp: Int) {
        val manager = irManager
        if (manager != null && manager.hasIrEmitter()) {
            try {
                val beaconPattern = GreeYt1fProtocol.generateIFeelBeacon(temp)
                manager.transmit(GreeYt1fProtocol.CARRIER_FREQUENCY, beaconPattern)
                Toast.makeText(this, "I-Feel beacon sent (${temp}°C)", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {}
        }
    }
}
