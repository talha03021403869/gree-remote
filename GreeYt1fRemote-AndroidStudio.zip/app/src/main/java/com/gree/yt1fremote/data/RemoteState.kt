package com.gree.yt1fremote.data

enum class AcMode {
    AUTO,
    COOL,
    DRY,
    FAN,
    HEAT
}

enum class FanSpeed {
    AUTO,
    LOW,
    MEDIUM,
    HIGH
}

enum class VerticalSwing {
    OFF,
    AUTO,
    UP,
    MID_UP,
    MID,
    MID_DOWN,
    DOWN
}

data class RemoteState(
    val power: Boolean = true,
    val temperature: Int = 25,
    val mode: AcMode = AcMode.COOL,
    val fanSpeed: FanSpeed = FanSpeed.AUTO,
    val verticalSwing: VerticalSwing = VerticalSwing.AUTO,
    val horizontalSwing: Boolean = false,
    val turbo: Boolean = false,
    val light: Boolean = true,
    val xQuietFan: Boolean = false,
    val sleep: Boolean = false,
    val iFeel: Boolean = false,
    val clockTime: String = "12:01",
    val timerOnEnabled: Boolean = false,
    val timerOnHours: Int = 2,
    val timerOffEnabled: Boolean = false,
    val timerOffHours: Int = 4
)
