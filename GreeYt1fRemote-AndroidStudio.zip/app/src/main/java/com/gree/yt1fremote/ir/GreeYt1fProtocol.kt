package com.gree.yt1fremote.ir

import com.gree.yt1fremote.data.AcMode
import com.gree.yt1fremote.data.FanSpeed
import com.gree.yt1fremote.data.RemoteState
import com.gree.yt1fremote.data.VerticalSwing

/**
 * Verified Gree YT1F Infrared Protocol Implementation
 *
 * Carrier Frequency: 38,000 Hz (38 kHz)
 * Frame: 67 bits (Block 1: 32 bits, 20ms pause, Block 2: 32 bits + 3 trailer bits)
 * Verified against ToniA arduino-heatpumpir (GreeYTHeatpumpIR) and IRremoteESP8266.
 */
object GreeYt1fProtocol {

    const val CARRIER_FREQUENCY = 38000 // 38 kHz

    // Microsecond timing constants
    private const val HDR_MARK = 9000
    private const val HDR_SPACE = 4500
    private const val BIT_MARK = 620
    private const val ONE_SPACE = 1600
    private const val ZERO_SPACE = 540
    private const val BLOCK_SPACE = 20000 // 20 ms inter-block gap
    private const val TRAIL_SPACE = 40000

    // I-Feel Beacon Timings
    private const val IFEEL_HDR_MARK = 6000
    private const val IFEEL_HDR_SPACE = 3000

    fun encodeStateToPulses(state: RemoteState): IntArray {
        val bytes = ByteArray(8)

        // Byte 0: Mode (bits 0-2), Power (bit 3), Fan Speed (bits 4-5), Swing (bit 6), Sleep (bit 7)
        var b0 = when (state.mode) {
            AcMode.AUTO -> 0b000
            AcMode.COOL -> 0b001
            AcMode.DRY  -> 0b010
            AcMode.FAN  -> 0b011
            AcMode.HEAT -> 0b100
        }
        if (state.power) b0 = b0 or (1 shl 3)
        val fanBits = when (state.fanSpeed) {
            FanSpeed.AUTO   -> 0b00
            FanSpeed.LOW    -> 0b01
            FanSpeed.MEDIUM -> 0b10
            FanSpeed.HIGH   -> 0b11
        }
        b0 = b0 or (fanBits shl 4)
        if (state.verticalSwing != VerticalSwing.OFF) b0 = b0 or (1 shl 6)
        if (state.sleep) b0 = b0 or (1 shl 7)
        bytes[0] = b0.toByte()

        // Byte 1: Temperature (bits 0-3: temp - 16) + Timer ON
        val clampedTemp = state.temperature.coerceIn(16, 30)
        var b1 = (clampedTemp - 16) and 0x0F
        if (state.timerOnEnabled) {
            b1 = b1 or ((state.timerOnHours and 0x0F) shl 4)
        }
        bytes[1] = b1.toByte()

        // Byte 2: Turbo (bit 4), Light (bit 5), X-Fan (bit 7)
        var b2 = if (state.light) 0x20 else 0x00
        if (state.turbo) b2 = b2 or (1 shl 4)
        if (state.xQuietFan) b2 = b2 or (1 shl 7)
        bytes[2] = b2.toByte()

        // Byte 3: YT1F Model Signature (0x50)
        bytes[3] = 0x50.toByte()

        // Byte 4: Vertical Swing & Horizontal Swing
        var b4 = when (state.verticalSwing) {
            VerticalSwing.OFF      -> 0x00
            VerticalSwing.AUTO     -> 0x01
            VerticalSwing.UP       -> 0x02
            VerticalSwing.MID_UP   -> 0x03
            VerticalSwing.MID      -> 0x04
            VerticalSwing.MID_DOWN -> 0x05
            VerticalSwing.DOWN     -> 0x06
        }
        if (state.horizontalSwing) b4 = b4 or (0x01 shl 4)
        bytes[4] = b4.toByte()

        // Byte 5: Temp Display Mode & I-Feel flag
        var b5 = 0x00
        if (state.iFeel) b5 = b5 or (1 shl 2)
        bytes[5] = b5.toByte()

        // Byte 6: Timer OFF payload
        bytes[6] = (if (state.timerOffEnabled) state.timerOffHours and 0x0F else 0x00).toByte()

        // Byte 7: Verified Gree YT1F Checksum
        // Checksum formula: (sum of low nibbles of b0..b3 + high nibbles of b4..b6 + 0x0A) & 0x0F << 4
        val b0Nib = bytes[0].toInt() and 0x0F
        val b1Nib = bytes[1].toInt() and 0x0F
        val b2Nib = bytes[2].toInt() and 0x0F
        val b3Nib = bytes[3].toInt() and 0x0F
        val b4High = (bytes[4].toInt() and 0xF0) shr 4
        val b5High = (bytes[5].toInt() and 0xF0) shr 4
        val b6High = (bytes[6].toInt() and 0xF0) shr 4

        val sum = (b0Nib + b1Nib + b2Nib + b3Nib + b4High + b5High + b6High + 0x0A) and 0x0F
        bytes[7] = ((sum shl 4) and 0xFF).toByte()

        return convertBytesToTimingPattern(bytes)
    }

    private fun convertBytesToTimingPattern(bytes: ByteArray): IntArray {
        val pulses = mutableListOf<Int>()

        // 1. Header (9ms mark, 4.5ms space)
        pulses.add(HDR_MARK)
        pulses.add(HDR_SPACE)

        // 2. Block 1 (Bytes 0 to 3)
        for (i in 0..3) {
            val byteVal = bytes[i].toInt() and 0xFF
            for (bit in 0..7) {
                pulses.add(BIT_MARK)
                val isOne = ((byteVal shr bit) and 1) == 1
                pulses.add(if (isOne) ONE_SPACE else ZERO_SPACE)
            }
        }

        // 3. 20ms Inter-block gap
        pulses.add(BIT_MARK)
        pulses.add(BLOCK_SPACE)

        // 4. Block 2 (Bytes 4 to 7)
        for (i in 4..7) {
            val byteVal = bytes[i].toInt() and 0xFF
            for (bit in 0..7) {
                pulses.add(BIT_MARK)
                val isOne = ((byteVal shr bit) and 1) == 1
                pulses.add(if (isOne) ONE_SPACE else ZERO_SPACE)
            }
        }

        // 5. 3 Trailer bits (0b000)
        for (t in 0..2) {
            pulses.add(BIT_MARK)
            pulses.add(ZERO_SPACE)
        }

        // 6. Stop pulse mark & trailing quiet space
        pulses.add(BIT_MARK)
        pulses.add(TRAIL_SPACE)

        return pulses.toIntArray()
    }

    /**
     * Gree YT1F I-Feel Sensed Temperature Beacon: [temperature, 0xA5]
     */
    fun generateIFeelBeacon(roomTemp: Int): IntArray {
        val pulses = mutableListOf<Int>()
        val clamped = roomTemp.coerceIn(16, 35)
        val payload = intArrayOf(clamped, 0xA5)

        pulses.add(IFEEL_HDR_MARK)
        pulses.add(IFEEL_HDR_SPACE)

        for (byteVal in payload) {
            for (bit in 0..7) {
                pulses.add(BIT_MARK)
                val isOne = ((byteVal shr bit) and 1) == 1
                pulses.add(if (isOne) ONE_SPACE else ZERO_SPACE)
            }
        }

        pulses.add(BIT_MARK)
        pulses.add(10000)
        return pulses.toIntArray()
    }
}
