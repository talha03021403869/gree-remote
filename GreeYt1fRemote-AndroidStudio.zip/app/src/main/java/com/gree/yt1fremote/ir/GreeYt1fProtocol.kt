package com.gree.yt1fremote.ir

import com.gree.yt1fremote.data.AcMode
import com.gree.yt1fremote.data.FanSpeed
import com.gree.yt1fremote.data.RemoteState
import com.gree.yt1fremote.data.VerticalSwing

/**
 * Gree YT-family frame encoder based on the published GreeYTHeatpumpIR
 * implementation (ToniA/arduino-heatpumpir).
 *
 * IMPORTANT: This is a protocol-informed correction, not a confirmation that
 * every YT1F variant/feature is supported. Confirm against the actual AC.
 * The published YT implementation supports the core mode/power/temp/fan,
 * vertical swing, turbo/light and I-Feel fields. Timer, X-FAN, sleep and
 * horizontal swing are not implemented here because the cited YT encoder
 * does not define those fields for this model.
 */
object GreeYt1fProtocol {
    const val CARRIER_FREQUENCY = 38000

    private const val HEADER_MARK = 9000
    private const val HEADER_SPACE = 4000
    private const val BIT_MARK = 620
    private const val ONE_SPACE = 1600
    private const val ZERO_SPACE = 540
    private const val MESSAGE_SPACE = 19000
    private const val IFEEL_HEADER_MARK = 8200
    private const val IFEEL_HEADER_SPACE = 3800
    private const val IFEEL_BIT_MARK = 650

    /** Returns the YT-family 9-byte payload as the 67-bit timing sequence. */
    fun encodeStateToPulses(state: RemoteState): IntArray {
        val bytes = ByteArray(9)
        val mode = when (state.mode) {
            AcMode.AUTO -> 0x00
            AcMode.COOL -> 0x01
            AcMode.DRY -> 0x02
            AcMode.FAN -> 0x03
            AcMode.HEAT -> 0x04
        }
        val fan = when (state.fanSpeed) {
            FanSpeed.AUTO -> 0x00
            FanSpeed.LOW -> 0x10
            FanSpeed.MEDIUM -> 0x20
            FanSpeed.HIGH -> 0x30
        }
        val power = if (state.power) 0x08 else 0x00
        val verticalSwing = state.verticalSwing != VerticalSwing.OFF
        bytes[0] = (mode or fan or power or if (verticalSwing) 0x40 else 0).toByte()
        bytes[1] = (state.temperature.coerceIn(16, 30) - 16).toByte()

        // YT implementation sets LIGHT and HEALTH bits for this remote family.
        var featureByte = 0x20 or 0x40
        if (state.turbo) featureByte = featureByte or 0x10
        bytes[2] = featureByte.toByte()
        bytes[3] = 0x50.toByte()
        // Byte 4's 3 transmitted bits are fixed by the published YT sender.
        bytes[4] = 0x02.toByte()
        if (state.iFeel) bytes[5] = 0x08.toByte()
        // bytes 6 and 7 are reserved/zero for the published YT frame.
        bytes[8] = checksum(bytes)

        val pulses = ArrayList<Int>(150)
        pulses += HEADER_MARK
        pulses += HEADER_SPACE
        for (i in 0..3) appendByte(pulses, bytes[i].toInt() and 0xFF)

        // The YT sender transmits the fixed 3-bit sequence 010 (LSB first).
        pulses += BIT_MARK; pulses += ZERO_SPACE
        pulses += BIT_MARK; pulses += ONE_SPACE
        pulses += BIT_MARK; pulses += ZERO_SPACE

        pulses += BIT_MARK
        pulses += MESSAGE_SPACE
        for (i in 5..8) appendByte(pulses, bytes[i].toInt() and 0xFF)
        pulses += BIT_MARK
        return pulses.toIntArray()
    }

    private fun appendByte(out: MutableList<Int>, value: Int) {
        for (bit in 0..7) {
            out += BIT_MARK
            out += if (((value ushr bit) and 1) != 0) ONE_SPACE else ZERO_SPACE
        }
    }

    private fun checksum(bytes: ByteArray): Byte {
        val sum = ((bytes[0].toInt() and 0x0F) +
            (bytes[1].toInt() and 0x0F) +
            (bytes[2].toInt() and 0x0F) +
            (bytes[3].toInt() and 0x0F) +
            ((bytes[5].toInt() and 0xF0) ushr 4) +
            ((bytes[6].toInt() and 0xF0) ushr 4) +
            ((bytes[7].toInt() and 0xF0) ushr 4) + 0x0A) and 0x0F
        return (((sum shl 4) or (bytes[7].toInt() and 0x0F)) and 0xFF).toByte()
    }

    /** Separate 2-byte I-Feel temperature beacon used by the Gree YT family. */
    fun generateIFeelBeacon(roomTemp: Int): IntArray {
        val payload = intArrayOf(roomTemp.coerceIn(16, 35), 0xA5)
        val pulses = ArrayList<Int>(40)
        pulses += IFEEL_HEADER_MARK
        pulses += IFEEL_HEADER_SPACE
        for (value in payload) {
            for (bit in 0..7) {
                pulses += IFEEL_BIT_MARK
                pulses += if (((value ushr bit) and 1) != 0) ONE_SPACE else ZERO_SPACE
            }
        }
        pulses += IFEEL_BIT_MARK
        pulses += 0
        return pulses.toIntArray()
    }
}
