package com.gree.yt1fremote.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.gree.yt1fremote.R
import com.gree.yt1fremote.data.AcMode
import com.gree.yt1fremote.data.FanSpeed
import com.gree.yt1fremote.data.RemoteState
import com.gree.yt1fremote.data.VerticalSwing

@Composable
fun RemoteScreen(
    state: RemoteState,
    hasIrEmitter: Boolean,
    soundEnabled: Boolean,
    onSoundToggle: () -> Unit,
    onButtonClick: () -> Unit,
    onStateChange: (RemoteState) -> Unit,
    onLightToggle: (RemoteState) -> Unit,
    onTransmitIFeelBeacon: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(42.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onSoundToggle) {
                Text(
                    if (soundEnabled) "🔊 Sound ON" else "🔇 Sound OFF",
                    color = Color(0xFF334155)
                )
            }
        }

        BoxWithConstraints(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
        ) {
            // The supplied original remote photo is shown with its proportions preserved.
            val remoteWidth = maxHeight * (520f / 1315f)
            Box(
                modifier = Modifier
                    .height(maxHeight * 0.94f)
                    .width(remoteWidth * 0.94f)
            ) {
                Image(
                    painter = painterResource(R.drawable.gree_yt1f_remote),
                    contentDescription = "Original GREE YT1F air-conditioner remote",
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.FillBounds
                )

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val w = maxWidth
                    val h = maxHeight

                    fun hotspot(cx: Float, cy: Float, ww: Float = 0.19f, hh: Float = 0.055f): Modifier =
                        Modifier
                            .offset(x = w * cx - w * ww / 2f, y = h * cy - h * hh / 2f)
                            .size(width = w * ww, height = h * hh)

                    // Temperature down
                    Box(hotspot(0.26f, 0.449f).clickable {
                        onButtonClick()
                        if (state.temperature > 16) onStateChange(state.copy(temperature = state.temperature - 1))
                    })
                    // Power
                    Box(hotspot(0.517f, 0.466f).clickable {
                        onButtonClick()
                        onStateChange(state.copy(power = !state.power))
                    })
                    // Temperature up
                    Box(hotspot(0.759f, 0.449f).clickable {
                        onButtonClick()
                        if (state.temperature < 30) onStateChange(state.copy(temperature = state.temperature + 1))
                    })
                    // Fan speed
                    Box(hotspot(0.333f, 0.52f).clickable {
                        onButtonClick()
                        val next = when (state.fanSpeed) {
                            FanSpeed.AUTO -> FanSpeed.LOW
                            FanSpeed.LOW -> FanSpeed.MEDIUM
                            FanSpeed.MEDIUM -> FanSpeed.HIGH
                            FanSpeed.HIGH -> FanSpeed.AUTO
                        }
                        onStateChange(state.copy(fanSpeed = next))
                    })
                    // Mode
                    Box(hotspot(0.69f, 0.52f).clickable {
                        onButtonClick()
                        val next = when (state.mode) {
                            AcMode.AUTO -> AcMode.COOL
                            AcMode.COOL -> AcMode.DRY
                            AcMode.DRY -> AcMode.FAN
                            AcMode.FAN -> AcMode.HEAT
                            AcMode.HEAT -> AcMode.AUTO
                        }
                        onStateChange(state.copy(mode = next))
                    })
                    // I FEEL
                    Box(hotspot(0.505f, 0.552f, 0.25f, 0.045f).clickable {
                        onButtonClick()
                        val enabled = !state.iFeel
                        onStateChange(state.copy(iFeel = enabled))
                        if (enabled) onTransmitIFeelBeacon()
                    })
                    // Vertical swing / tree symbol
                    Box(hotspot(0.31f, 0.587f).clickable {
                        onButtonClick()
                        val next = if (state.verticalSwing == VerticalSwing.OFF) VerticalSwing.AUTO else VerticalSwing.OFF
                        onStateChange(state.copy(verticalSwing = next))
                    })
                    // Horizontal swing / house symbol
                    Box(hotspot(0.71f, 0.587f).clickable {
                        onButtonClick()
                        onStateChange(state.copy(horizontalSwing = !state.horizontalSwing))
                    })
                    // Clock (existing button has no action)
                    Box(hotspot(0.31f, 0.648f).clickable { onButtonClick() })
                    // Timer ON
                    Box(hotspot(0.505f, 0.648f).clickable {
                        onButtonClick()
                        onStateChange(state.copy(timerOnEnabled = !state.timerOnEnabled))
                    })
                    // Display/light icon row
                    Box(hotspot(0.71f, 0.648f).clickable {
                        onButtonClick()
                        onLightToggle(state.copy(light = !state.light, power = state.power))
                    })
                    // BLOW / X-FAN
                    Box(hotspot(0.31f, 0.696f).clickable {
                        onButtonClick()
                        onStateChange(state.copy(xQuietFan = !state.xQuietFan))
                    })
                    // TEMP (existing button has no action)
                    Box(hotspot(0.505f, 0.696f).clickable { onButtonClick() })
                    // Timer OFF
                    Box(hotspot(0.71f, 0.696f).clickable {
                        onButtonClick()
                        onStateChange(state.copy(timerOffEnabled = !state.timerOffEnabled))
                    })
                    // Turbo
                    Box(hotspot(0.31f, 0.749f).clickable {
                        onButtonClick()
                        onStateChange(state.copy(turbo = !state.turbo))
                    })
                    // Sleep
                    Box(hotspot(0.505f, 0.749f).clickable {
                        onButtonClick()
                        onStateChange(state.copy(sleep = !state.sleep))
                    })
                    // Light
                    Box(hotspot(0.71f, 0.749f).clickable {
                        onButtonClick()
                        onLightToggle(state.copy(light = !state.light, power = state.power))
                    })
                }
            }
        }
    }
}
