package com.gree.yt1fremote.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gree.yt1fremote.data.AcMode
import com.gree.yt1fremote.data.FanSpeed
import com.gree.yt1fremote.data.RemoteState
import com.gree.yt1fremote.data.VerticalSwing
import com.gree.yt1fremote.ui.components.LcdDisplay

@Composable
fun RemoteScreen(
    state: RemoteState,
    hasIrEmitter: Boolean,
    onStateChange: (RemoteState) -> Unit,
    onTransmitIFeelBeacon: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Gree YT1F Silver Remote Housing
        Box(
            modifier = Modifier
                .width(320.dp)
                .shadow(elevation = 18.dp, shape = RoundedCornerShape(32.dp))
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFDCE2E8),
                            Color(0xFFBCC6D0),
                            Color(0xFFA2ACB6),
                            Color(0xFFC8D1D8)
                        )
                    )
                )
                .border(2.dp, Color(0xFFF1F5F9), RoundedCornerShape(32.dp))
                .padding(16.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Top IR Emitter Bezel
                Box(
                    modifier = Modifier
                        .size(width = 38.dp, height = 7.dp)
                        .clip(RoundedCornerShape(3.5.dp))
                        .background(Color(0xFF1E293B))
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 1. LCD Screen Panel
                LcdDisplay(state = state)

                Spacer(modifier = Modifier.height(16.dp))

                // 2. Primary Cluster: [-] Temp | Circular POWER | [+] Temp
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // [-] Temperature
                    Button(
                        onClick = {
                            if (state.temperature > 16) {
                                onStateChange(state.copy(temperature = state.temperature - 1))
                            }
                        },
                        modifier = Modifier.size(width = 68.dp, height = 44.dp).shadow(4.dp, RoundedCornerShape(22.dp)),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("–", fontSize = 24.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }

                    // Central Circular Power Button
                    Button(
                        onClick = { onStateChange(state.copy(power = !state.power)) },
                        modifier = Modifier.size(72.dp).shadow(6.dp, CircleShape),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                        border = BorderStroke(2.dp, Color(0xFF94A3B8))
                    ) {
                        Text("⏻", color = Color(0xFFDC2626), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    }

                    // [+] Temperature
                    Button(
                        onClick = {
                            if (state.temperature < 30) {
                                onStateChange(state.copy(temperature = state.temperature + 1))
                            }
                        },
                        modifier = Modifier.size(width = 68.dp, height = 44.dp).shadow(4.dp, RoundedCornerShape(22.dp)),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("+", fontSize = 24.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 3. Cluster: MODE | I FEEL | FAN
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            val nextMode = when (state.mode) {
                                AcMode.AUTO -> AcMode.COOL
                                AcMode.COOL -> AcMode.DRY
                                AcMode.DRY -> AcMode.FAN
                                AcMode.FAN -> AcMode.HEAT
                                AcMode.HEAT -> AcMode.AUTO
                            }
                            onStateChange(state.copy(mode = nextMode))
                        },
                        modifier = Modifier.size(width = 72.dp, height = 38.dp).shadow(3.dp, RoundedCornerShape(19.dp)),
                        shape = RoundedCornerShape(19.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("MODE", fontSize = 11.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val newIFeel = !state.iFeel
                            onStateChange(state.copy(iFeel = newIFeel))
                            if (newIFeel) onTransmitIFeelBeacon()
                        },
                        modifier = Modifier.size(width = 84.dp, height = 36.dp).shadow(3.dp, RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.iFeel) Color(0xFFE0F2FE) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(1.dp, if (state.iFeel) Color(0xFF38BDF8) else Color(0xFFCBD5E1))
                    ) {
                        Text("I FEEL", fontSize = 11.sp, color = Color(0xFF0369A1), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val nextFan = when (state.fanSpeed) {
                                FanSpeed.AUTO -> FanSpeed.LOW
                                FanSpeed.LOW -> FanSpeed.MEDIUM
                                FanSpeed.MEDIUM -> FanSpeed.HIGH
                                FanSpeed.HIGH -> FanSpeed.AUTO
                            }
                            onStateChange(state.copy(fanSpeed = nextFan))
                        },
                        modifier = Modifier.size(width = 72.dp, height = 38.dp).shadow(3.dp, RoundedCornerShape(19.dp)),
                        shape = RoundedCornerShape(19.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("FAN", fontSize = 11.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 4. Cluster: Vertical SWING | Horizontal SWING
                Row(
                    modifier = Modifier.fillMaxWidth(0.88f),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = {
                            val nextSwing = if (state.verticalSwing == VerticalSwing.OFF) VerticalSwing.AUTO else VerticalSwing.OFF
                            onStateChange(state.copy(verticalSwing = nextSwing))
                        },
                        modifier = Modifier.size(width = 110.dp, height = 34.dp).shadow(3.dp, RoundedCornerShape(17.dp)),
                        shape = RoundedCornerShape(17.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("↕ SWING", fontSize = 11.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            onStateChange(state.copy(horizontalSwing = !state.horizontalSwing))
                        },
                        modifier = Modifier.size(width = 110.dp, height = 34.dp).shadow(3.dp, RoundedCornerShape(17.dp)),
                        shape = RoundedCornerShape(17.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("☖ SWING", fontSize = 11.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 5. Row: CLOCK | TIMER ON | TIMER OFF
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = {},
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("CLOCK", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { onStateChange(state.copy(timerOnEnabled = !state.timerOnEnabled)) },
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.timerOnEnabled) Color(0xFFE0F2FE) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("TIMER ON", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { onStateChange(state.copy(timerOffEnabled = !state.timerOffEnabled)) },
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.timerOffEnabled) Color(0xFFE0F2FE) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("TIMER OFF", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 6. Row: X-FAN | TEMP | TURBO
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { onStateChange(state.copy(xQuietFan = !state.xQuietFan)) },
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.xQuietFan) Color(0xFFE0F2FE) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("X-FAN", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {},
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF8FAFC)),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("TEMP", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = { onStateChange(state.copy(turbo = !state.turbo)) },
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.turbo) Color(0xFFFEF3C7) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("TURBO", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 7. Row: SLEEP | LIGHT
                Row(
                    modifier = Modifier.fillMaxWidth(0.72f),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { onStateChange(state.copy(sleep = !state.sleep)) },
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.sleep) Color(0xFFEDE9FE) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("SLEEP", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onStateChange(state.copy(light = !state.light)) },
                        modifier = Modifier.weight(1f).height(34.dp).shadow(2.dp, RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.light) Color(0xFFDCFCE7) else Color(0xFFF8FAFC)
                        ),
                        border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                    ) {
                        Text("LIGHT", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // YT1F Brand stamp
                Text("GREE YT1F", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569))
            }
        }
    }
}
