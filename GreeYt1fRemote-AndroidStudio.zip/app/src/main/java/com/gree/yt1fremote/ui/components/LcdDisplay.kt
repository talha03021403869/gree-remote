package com.gree.yt1fremote.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gree.yt1fremote.data.AcMode
import com.gree.yt1fremote.data.FanSpeed
import com.gree.yt1fremote.data.RemoteState
import com.gree.yt1fremote.data.VerticalSwing

@Composable
fun LcdDisplay(state: RemoteState) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFB4C2B4))
            .border(2.dp, Color(0xFF8F9F8F), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        if (!state.power) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "STANDBY",
                    color = Color(0x331E2A1E),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top line: FAN speed bars & OPER
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("FAN", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))
                        Spacer(modifier = Modifier.width(4.dp))
                        val bars = when (state.fanSpeed) {
                            FanSpeed.AUTO   -> "AUTO"
                            FanSpeed.LOW    -> "▂"
                            FanSpeed.MEDIUM -> "▂▄"
                            FanSpeed.HIGH   -> "▂▄▆"
                        }
                        Text(bars, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))
                    }

                    Text("OPER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))
                }

                // Middle: Mode & Big Temperature
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val modeLabel = when (state.mode) {
                        AcMode.AUTO -> "AUTO ⟳"
                        AcMode.COOL -> "❄ COOL"
                        AcMode.DRY  -> "💧 DRY"
                        AcMode.FAN  -> "✦ FAN"
                        AcMode.HEAT -> "☼ HEAT"
                    }
                    Text(modeLabel, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))

                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            "${state.temperature}",
                            fontSize = 62.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF1E2A1E)
                        )
                        Text("°C", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E), modifier = Modifier.padding(top = 8.dp))
                    }

                    if (state.verticalSwing != VerticalSwing.OFF) {
                        Text("彡", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))
                    }
                }

                // Bottom indicators
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🕒 ${state.clockTime}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF1E2A1E))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (state.iFeel) Text("I FEEL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))
                        if (state.turbo) Text("TURBO", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))
                        if (state.xQuietFan) Text("X-FAN", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2A1E))
                        if (state.sleep) Text("🌙", fontSize = 11.sp, color = Color(0xFF1E2A1E))
                        if (state.light) Text("💡", fontSize = 11.sp, color = Color(0xFF1E2A1E))
                    }
                }
            }
        }
    }
}
